public class Log {
    // Private static instance of Logger
    private static Log instance;

    // Private constructor to prevent instantiation
    private Log() {
    }

    // Public static method to get the instance of Logger
    public static Log getInstance() {
        if (instance == null) {
            instance = new Log();
        }
        return instance;
    }

    // Method to log messages
    public void log(String message) {
        System.out.println("Log message: " + message);
    }
}
